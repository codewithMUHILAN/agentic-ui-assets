const { useState, useEffect, useCallback, useRef } = React;

        const DEFAULT_SLIDES = [
            {
                image: { src: "https://imagedelivery.net/IEUjvl3YUlxY-MrTpOAWDQ/7d4d2641-d6a8-4fef-e85c-b12ed100d500/w=800" },
                title: "James Walker",
            },
            {
                image: { src: "https://imagedelivery.net/IEUjvl3YUlxY-MrTpOAWDQ/933a7615-f4b6-4eae-8ed1-705fa0e24400/w=800" },
                title: "Olivia Carter",
            },
            {
                image: { src: "https://imagedelivery.net/IEUjvl3YUlxY-MrTpOAWDQ/859c75ea-953e-489e-be61-91a03a35d700/w=800" },
                title: "Amelia Foster",
            },
            {
                image: { src: "https://imagedelivery.net/IEUjvl3YUlxY-MrTpOAWDQ/31afae9c-5ba3-4ec3-2534-ed8198ed1100/w=800" },
                title: "Benjamin Harris",
            },
            {
                image: { src: "https://imagedelivery.net/IEUjvl3YUlxY-MrTpOAWDQ/ed7b1c40-3332-43d8-a9eb-4615ef341b00/w=800" },
                title: "Lucas Martin",
            },
        ];

        const COMPONENT_DEFAULTS = {
            slides: DEFAULT_SLIDES,
            cardWidth: 400,
            cardHeight: 400,
            radius: 3,
            tilt: 12,
            sideTilt: 8,
            gap: 8,
            opacity: 60,
            autoplay: false,
            autoplayDirection: "rightToLeft",
            transition: {
                type: "tween",
                duration: 0.6,
                delay: 2.5,
                ease: [0.22, 1, 0.36, 1],
            },
            showTitle: true,
            titleFont: {
                fontFamily: "Inter",
                fontSize: "28px",
                letterSpacing: "-0.02em",
                lineHeight: "1.1em",
            },
            titleColor: "#ffffff",
            titlePosition: {
                position: "bottomLeft",
                paddingLeft: 22,
                paddingRight: 22,
                paddingTop: 24,
                paddingBottom: 24,
            },
        };

        const PERSPECTIVE = 1600;
        const SCALE_STEP = 0.16;
        const MAX_VISIBLE = 2;
        const DEPTH = 240;

        function cssTransition(t) {
            const dur = t && typeof t.duration === 'number' ? t.duration : 0.6;
            let ease = "cubic-bezier(0.22, 1, 0.36, 1)";
            const e = t?.ease;
            if (Array.isArray(e) && e.length === 4) {
                ease = `cubic-bezier(${e[0]}, ${e[1]}, ${e[2]}, ${e[3]})`;
            } else if (typeof e === "string") {
                const map = {
                    linear: "linear",
                    easeIn: "ease-in",
                    easeOut: "ease-out",
                    easeInOut: "ease-in-out",
                };
                ease = map[e] || "ease";
            }
            return { dur, ease };
        }

        function Smooth3DSlideshow(props) {
            props = { ...COMPONENT_DEFAULTS, ...props };
            const {
                slides,
                cardWidth,
                cardHeight,
                radius,
                tilt,
                sideTilt,
                gap,
                opacity,
                transition,
                autoplay,
                autoplayDirection,
                showTitle,
                titleFont,
                titleColor,
                titlePosition,
                style,
            } = props;

            const tp = titlePosition || {};
            const corner = tp.position || "bottomLeft";
            const isTop = corner === "topLeft" || corner === "topRight";
            const isRight = corner === "topRight" || corner === "bottomRight";
            const padLeft = tp.paddingLeft ?? 22;
            const padRight = tp.paddingRight ?? 22;
            const padTop = tp.paddingTop ?? 24;
            const padBottom = tp.paddingBottom ?? 24;

            const list = slides && slides.length ? slides : DEFAULT_SLIDES;
            const n = list.length;
            const loop = true;
            const [active, setActive] = useState(0);

            // Drag State Tracker Variables
            const dragStartX = useRef(0);
            const isDragging = useRef(false);
            const dragThreshold = 50; // Pixels required to trigger a slide switch

            useEffect(() => {
                setActive((a) => Math.max(0, Math.min(n - 1, a)));
            }, [n]);

            const moveDur = transition && typeof transition.duration === "number" ? transition.duration : 0.6;
            const lockRef = useRef(false);
            
            const lock = useCallback(() => {
                lockRef.current = true;
                window.setTimeout(() => {
                    lockRef.current = false;
                }, Math.max(50, moveDur * 1000));
            }, [moveDur]);

            const step = useCallback((dir) => {
                if (lockRef.current) return;
                lock();
                setActive((a) => (((a + dir) % n) + n) % n);
            }, [n, lock]);

            const handleCardClick = useCallback((i) => {
                if (autoplay || lockRef.current) return;
                lock();
                setActive((a) => (i === a ? (a + 1) % n : i));
            }, [autoplay, n, lock]);

            // Pointer interaction functions for Drag & Swipe
            const handlePointerDown = (e) => {
                if (autoplay || lockRef.current) return;
                isDragging.current = true;
                dragStartX.current = e.clientX;
                // Capture pointer to track movements even outside the immediate element boundaries
                e.currentTarget.setPointerCapture(e.pointerId);
            };

            const handlePointerMove = (e) => {
                if (!isDragging.current) return;
            };

            const handlePointerUp = (e) => {
                if (!isDragging.current) return;
                isDragging.current = false;
                e.currentTarget.releasePointerCapture(e.pointerId);

                const dragDistance = e.clientX - dragStartX.current;

                if (Math.abs(dragDistance) > dragThreshold) {
                    if (dragDistance > 0) {
                        step(-1); // Dragged right -> go to previous slide
                    } else {
                        step(1);  // Dragged left -> go to next slide
                    }
                }
            };

            const delay = transition && typeof transition.delay === "number" ? transition.delay : 2.5;
            
            useEffect(() => {
                if (!autoplay || n < 2) return;
                const ms = Math.max(0.3, delay) * 1000;
                const dir = autoplayDirection === "leftToRight" ? -1 : 1;
                const id = window.setInterval(() => step(dir), ms);
                return () => window.clearInterval(id);
            }, [autoplay, autoplayDirection, delay, n, step]);

            const onKeyDown = useCallback((e) => {
                if (e.key === "ArrowRight") {
                    e.preventDefault();
                    step(1);
                } else if (e.key === "ArrowLeft") {
                    e.preventDefault();
                    step(-1);
                }
            }, [step]);

            const { dur, ease } = cssTransition(transition);
            const transitionCss = `transform ${dur}s ${ease}, opacity ${dur}s ${ease}`;

            const effectiveRadius = (Math.max(0, Math.min(20, radius)) / 20) * (Math.min(cardWidth, cardHeight) / 2);
            const dim = 1 - Math.max(0, Math.min(100, opacity)) / 100;

            const rootStyle = {
                ...(style || {}),
                position: "relative",
                width: "100%",
                height: "100%",
                minWidth: 320,
                minHeight: 360,
                display: "flex",
                alignItems: "center",
                justifyContent: "center",
                perspective: `${PERSPECTIVE}px`,
                overflow: "hidden",
                outline: "none",
                touchAction: "none", /* Disables browser-default gestures like zooming/panning while swiping */
                cursor: autoplay ? "default" : "grab"
            };

            return (
                <div
                    style={rootStyle}
                    tabIndex={0}
                    role="group"
                    aria-roledescription="carousel"
                    onKeyDown={onKeyDown}
                    onPointerDown={handlePointerDown}
                    onPointerMove={handlePointerMove}
                    onPointerUp={handlePointerUp}
                    onPointerCancel={handlePointerUp}
                >
                    <div
                        style={{
                            position: "relative",
                            width: cardWidth,
                            height: cardHeight,
                            transformStyle: "preserve-3d",
                            pointerEvents: "none" /* Allows underlying root drag detection to seamlessly catch the pointer handles */
                        }}
                    >
                        {list.map((slide, i) => {
                            let rel = i - active;
                            if (loop) {
                                if (rel > n / 2) rel -= n;
                                if (rel < -n / 2) rel += n;
                            }
                            const ax = Math.abs(rel);
                            const visible = ax <= MAX_VISIBLE;
                            const isActive = rel === 0;
                            const sc = Math.max(0.4, 1 - ax * SCALE_STEP);
                            const tx = rel * (gap * 30);
                            const tz = -ax * DEPTH;
                            const ry = -rel * tilt;
                            const rz = rel * sideTilt;
                            const src = slide.image?.src || "";

                            const cardStyle = {
                                position: "absolute",
                                left: "50%",
                                top: "50%",
                                width: cardWidth,
                                height: cardHeight,
                                borderRadius: effectiveRadius,
                                overflow: "hidden",
                                transformStyle: "preserve-3d",
                                transformOrigin: "center center",
                                transform: `translate(-50%, -50%) translateX(${tx}px) translateZ(${tz}px) rotateY(${ry}deg) rotateZ(${rz}deg) scale(${sc})`,
                                transition: transitionCss,
                                opacity: visible ? 1 : 0,
                                pointerEvents: visible && !autoplay ? "auto" : "none",
                                backgroundColor: "#1a1a1a",
                            };

                            return (
                                <div
                                    key={i}
                                    style={cardStyle}
                                    onClick={(e) => {
                                        // Only handle clicks if the user clicked a side card without initiating a drag movement
                                        if(!isDragging.current) handleCardClick(i);
                                    }}
                                    aria-label={slide.title}
                                    aria-hidden={!visible}
                                >
                                    {src ? (
                                        <img
                                            src={src}
                                            alt={slide.image?.alt || slide.title || ""}
                                            draggable={false}
                                            style={{
                                                position: "absolute",
                                                inset: 0,
                                                width: "100%",
                                                height: "100%",
                                                objectFit: "cover",
                                                display: "block",
                                                userSelect: "none",
                                                pointerEvents: "none"
                                            }}
                                        />
                                    ) : null}

                                    {showTitle && (
                                        <React.Fragment>
                                            <div
                                                style={{
                                                    position: "absolute",
                                                    inset: 0,
                                                    background: isTop
                                                        ? "linear-gradient(0deg, rgba(0,0,0,0) 35%, rgba(0,0,0,0.7) 100%)"
                                                        : "linear-gradient(180deg, rgba(0,0,0,0) 35%, rgba(0,0,0,0.7) 100%)",
                                                    pointerEvents: "none",
                                                }}
                                            />

                                            <div
                                                style={{
                                                    position: "absolute",
                                                    left: padLeft,
                                                    right: padRight,
                                                    [isTop ? "top" : "bottom"]: isTop ? padTop : padBottom,
                                                    textAlign: isRight ? "right" : "left",
                                                    pointerEvents: "none",
                                                }}
                                            >
                                                <span
                                                    style={{
                                                        color: titleColor,
                                                        fontSize: 28,
                                                        fontWeight: 700,
                                                        lineHeight: "1.1em",
                                                        letterSpacing: "-0.02em",
                                                        whiteSpace: "pre-line",
                                                        textShadow: "0 2px 10px rgba(0,0,0,0.4)",
                                                        ...(titleFont || {}),
                                                    }}
                                                >
                                                    {slide.title}
                                                </span>
                                            </div>
                                        </React.Fragment>
                                    )}

                                    <div
                                        style={{
                                            position: "absolute",
                                            inset: 0,
                                            background: "#000000",
                                            opacity: isActive ? 0 : dim,
                                            transition: `opacity ${dur}s ${ease}`,
                                            pointerEvents: "none",
                                        }}
                                    />
                                </div>
                            );
                        })}
                    </div>
                </div>
            );
        }